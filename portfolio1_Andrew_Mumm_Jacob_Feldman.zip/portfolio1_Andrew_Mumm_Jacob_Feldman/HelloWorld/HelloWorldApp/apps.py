from django.apps import AppConfig


class HelloworldappConfig(AppConfig):
    name = 'HelloWorldApp'
